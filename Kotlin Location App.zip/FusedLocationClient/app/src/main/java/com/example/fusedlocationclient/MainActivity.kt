package com.example.fusedlocationclient

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*
import java.lang.Exception
import java.util.*
import java.util.concurrent.TimeUnit
import java.util.jar.Manifest
import java.util.Arrays

import java.text.SimpleDateFormat
import android.widget.EditText as EditText1


@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback
    private var currentLocation: Location? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val fileData = findViewById<EditText1>(R.id.editData)
        val btnView = findViewById<Button>(R.id.btnView)

        code()
        btnView.setOnClickListener(View.OnClickListener {
            val filename = "history.txt"
            if(filename.toString().trim()!=""){
                var fileInputStream: FileInputStream? = openFileInput(filename)
                var inputStreamReader: InputStreamReader = InputStreamReader(fileInputStream)
                val bufferedReader: BufferedReader = BufferedReader(inputStreamReader)
                val stringBuilder: StringBuilder = StringBuilder()
                var text: String? = null
                while ({ text = bufferedReader.readLine(); text }() != null) {
                    stringBuilder.append(text)
                }
                //Displaying data on EditText
                fileData.setText(stringBuilder.toString()).toString()
            }else{
                Toast.makeText(applicationContext,"file name cannot be blank",Toast.LENGTH_LONG).show()
            }
        })
//        save()
       // create_csv()


    }

    private fun code() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
            if (ActivityCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    this, android.Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    this, android.Manifest.permission.ACCESS_BACKGROUND_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(
                        android.Manifest.permission.ACCESS_COARSE_LOCATION,
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    ), 111
                )
            } else {
                locationRequest = LocationRequest().apply {
                    interval = TimeUnit.MINUTES.toMillis(15)
                    fastestInterval = TimeUnit.MINUTES.toMillis(5)
                    maxWaitTime = TimeUnit.MINUTES.toMillis(1)
                    priority = LocationRequest.PRIORITY_HIGH_ACCURACY
                }
                locationCallback = object : LocationCallback() {
                    @RequiresApi(Build.VERSION_CODES.N)
                    override fun onLocationResult(locationResult: LocationResult?) {
                        super.onLocationResult(locationResult)

                        if (locationResult?.lastLocation != null) {
                            currentLocation = locationResult.lastLocation
                            Longitude.setText(
                                "Longitude ${String.format(
                                    Locale.US,
                                    "%.2f",
                                    locationResult.lastLocation.longitude
                                )}"
                            )
                            Latitude.setText(
                                "Latitude ${String.format(
                                    Locale.US,
                                    "%.2f",
                                    locationResult.lastLocation.latitude
                                )}"
                            )
                            val file:String = "history.txt"
                            val latitude:String = String.format(
                                Locale.US,
                                "%.2f",
                                locationResult.lastLocation.latitude
                            )
                            val longitude:String = String.format(
                                Locale.US,
                                "%.2f",
                                locationResult.lastLocation.longitude
                            )
                            val fileOutputStream:FileOutputStream
                            try {
                                fileOutputStream = openFileOutput(file, Context.MODE_APPEND)
//                                val writer = PrintWriter(fileOutputStream)
                                fileOutputStream.write("Time : ${SimpleDateFormat("dd/M/yyyy hh:mm:ss").format(Date())}\n".toByteArray())
                                fileOutputStream.write(",".toByteArray())
                                fileOutputStream.write(latitude.toByteArray())
                                fileOutputStream.write(",".toByteArray())
                                fileOutputStream.write(longitude.toByteArray())




                            } catch (e: FileNotFoundException){
                                e.printStackTrace()
                            }catch (e: NumberFormatException){
                                e.printStackTrace()
                            }catch (e: IOException){
                                e.printStackTrace()
                            }catch (e: Exception){
                                e.printStackTrace()
                            }
                            Toast.makeText(applicationContext,"data save",Toast.LENGTH_LONG).show()
//                            fileName.text.clear()
//                            fileData.text.clear()
                        }


                         else {
                            System.out.println("error")
                        }
                    }
                }
                fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper())
            }
        }
    }


